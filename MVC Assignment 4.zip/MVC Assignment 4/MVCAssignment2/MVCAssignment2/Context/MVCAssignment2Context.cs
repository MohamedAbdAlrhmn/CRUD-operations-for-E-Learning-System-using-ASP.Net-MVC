﻿using Microsoft.EntityFrameworkCore;
using MVCAssignment2.Models;

namespace MVCAssignment2.Context
{
    public class MVCAssignment2Context:DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=.;Database=MVCAssignment2DB;Integrated Security=true;Encrypt=false;");
            base.OnConfiguring(optionsBuilder);
        }

        public DbSet<Course> courses { get; set; }

        public DbSet<CrsResult>crsResults { get; set; }

        public DbSet<Department>departments { get; set; }

        public DbSet<Instructor>instructors { get; set; }


        public DbSet<Trainee>trainees { get; set; }


    }
}
