﻿using Microsoft.AspNetCore.Mvc;
using MVCAssignment2.Context;
using MVCAssignment2.Models;

namespace MVCAssignment2.Controllers
{
    public class InstructorController : Controller
    {
        //Create Object from Context
        MVCAssignment2Context context = new MVCAssignment2Context();
        public IActionResult Index()
        {
            //Show List of Instructors
            //var InstructorList = context.instructors.ToList();
            //return View(InstructorList);
            var instructorList = context.instructors
        .Select(i => new
        {
            i.Id,
            i.Name,
            i.Age,
            i.Address,
            i.Salary,
            DeptName = context.departments.FirstOrDefault(d => d.Id == i.Dept_id).Name,
            CourseName = context.courses.FirstOrDefault(c => c.Id == i.Crs_id).Name
        }).ToList();

            // Pass the data to the view
            return View(instructorList);
        }

        public IActionResult Details(int Id)
        {
            //GetElementById
            var ExpectedInstructor = context.instructors.ToList().FirstOrDefault(x => x.Id == Id);
            return View(ExpectedInstructor);
        }

        public IActionResult AddnewInstructor()
        {
            ViewBag.depts = context.departments.ToList();
            ViewBag.courses = context.courses.ToList();
            return View();
        }

        public IActionResult SavenewInstructor(Instructor instructor)
        {
            if (instructor.Name != null)
            {
                context.instructors.Add(instructor);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View("AddnewInstructor", instructor);
        }

        [HttpGet]
        public IActionResult Edit(int Id)
        {
            //Get Instructor info with id
            var ins = context.instructors.FirstOrDefault(x => x.Id == Id);
            var depts = context.departments.ToList();
            var Crs = context.courses.ToList();
            if (ins != null)
            {
                ViewBag.depts = depts;
                ViewBag.courses = Crs;
                return View(ins);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public IActionResult Edit(int Id, Instructor newInstructor)
        {
            //Compare old data with new instructor data
            if (newInstructor.Name != null)
            {
                var oldinstructor = context.instructors.FirstOrDefault(i => i.Id == Id);
                oldinstructor.Name = newInstructor.Name;
                oldinstructor.Age = newInstructor.Age;
                oldinstructor.Address = newInstructor.Address;
                oldinstructor.Salary = newInstructor.Salary;
                oldinstructor.Dept_id = newInstructor.Dept_id;
                oldinstructor.Crs_id = newInstructor.Crs_id;

                context.SaveChanges();
                return RedirectToAction("Index");
            }

            var depts = context.departments.ToList();
            var Crs = context.courses.ToList();
            ViewBag.depts = depts;
            ViewBag.courses = Crs;
            return View(newInstructor);

        }
    }
}
