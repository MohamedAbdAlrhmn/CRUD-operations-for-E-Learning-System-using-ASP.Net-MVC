﻿using Microsoft.AspNetCore.Mvc;
using MVCAssignment2.Context;
using MVCAssignment2.Models;

namespace MVCAssignment2.Controllers
{
    public class TraineeController : Controller
    {
        //Create Object from Context
        MVCAssignment2Context context = new MVCAssignment2Context();
        public IActionResult Index()
        {
            var traineeList = context.trainees.
           Select(t => new
           {
               t.Id,
               t.Name,
               t.Age,
               t.Grade,
               t.Address,
               DeptName = context.departments.FirstOrDefault(d => d.Id == t.Dept_id).Name
           }).ToList();
            return View(traineeList);
        }

        public IActionResult AddnewTrainee()
        {
            ViewBag.depts = context.departments.ToList();
            return View();
        }

        public IActionResult SavenewTrainee(Trainee trainee)
        {
            if (trainee.Name != null)
            {
                context.trainees.Add(trainee);
                context.SaveChanges();
                return RedirectToAction("Index");
            }

            return View("AddnewTrainee", trainee);
        }

        [HttpGet]
        public IActionResult EditTrainee(int Id)
        {
            var trainee = context.trainees.FirstOrDefault(t => t.Id == Id);
            var depts = context.departments.ToList();

            if (trainee != null)
            {
                ViewBag.depts = depts;
                return View(trainee);
            }

            else
            {
                return RedirectToAction("Index");
            }

        }

        [HttpPost]
        public IActionResult EditTrainee(int Id, Trainee newtrainee)
        {
            if (newtrainee.Name != null)
            {
                var oldtrainee = context.trainees.FirstOrDefault(t => t.Id == Id);
                oldtrainee.Name = newtrainee.Name;
                oldtrainee.Age = newtrainee.Age;
                oldtrainee.Address = newtrainee.Address;
                oldtrainee.Grade = newtrainee.Grade;
                oldtrainee.Dept_id = newtrainee.Dept_id;
                context.SaveChanges();
                return RedirectToAction("Index");
            }

            else
            {
                var depts = context.departments.ToList();
                ViewBag.depts = depts;
                return View(newtrainee);
            }
        }


    }
}
