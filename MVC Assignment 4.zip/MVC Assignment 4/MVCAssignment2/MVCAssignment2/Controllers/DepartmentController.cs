﻿using Microsoft.AspNetCore.Mvc;
using MVCAssignment2.Context;
using MVCAssignment2.Models;

namespace MVCAssignment2.Controllers
{
    public class DepartmentController : Controller
    {
        MVCAssignment2Context context = new MVCAssignment2Context();
        public IActionResult Index()
        {
            var depts = context.departments.ToList();
            return View(depts);
        }

        public IActionResult New()
        {
            return View();
        }

        public IActionResult SaveNewDepartment(Department department)
        {
            if (department.Name != null && department.ManagerName != null)
            {
                context.departments.Add(department);
                context.SaveChanges();
                //var depts = context.Department.ToList();
                //return View("Index", depts);
                return RedirectToAction("Index");
            }

            return View("New", department);
        }

        [HttpGet]
        public IActionResult EditDepartment(int Id)
        {
            var dept = context.departments.FirstOrDefault(x => x.Id == Id);
            if (dept != null)
            {
                return View(dept);
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult EditDepartment(Department newDept)
        {

            if (newDept.Name != null)
            {
                var data = context.Update(newDept);
                context.SaveChanges();
                return RedirectToAction("Index");

            }
            return View(newDept);

        }
    }
}
