﻿using Microsoft.AspNetCore.Mvc;
using MVCAssignment2.Context;
using MVCAssignment2.Models;

namespace MVCAssignment2.Controllers
{
    public class CourseController : Controller
    {
        MVCAssignment2Context context = new MVCAssignment2Context();
        public IActionResult Index()
        {
            var courseList = context.courses.
           Select(c => new
           {
               c.Id,
               c.Name,
               c.Dgree,
               c.MinDegree,
               Deptname = context.departments.FirstOrDefault(d => d.Id == c.Dept_id).Name

           }).ToList();
            return View(courseList);
        }

        public IActionResult AddNewCourse()
        {
            ViewBag.depts = context.departments.ToList();
            return View();
        }

        public IActionResult SaveNewCourse(Course course)
        {
            if (course.Name != null)
            {
                context.courses.Add(course);
                context.SaveChanges();
                return RedirectToAction("Index");
            }

            return View("AddNewCourse", course);
        }

        [HttpGet]
        public IActionResult EditCourse(int Id)
        {
            var courses = context.courses.FirstOrDefault(c => c.Id == Id);
            var depts = context.departments.ToList();
            ViewBag.Depts = depts;

            if (courses != null)
            {
                return View(courses);
            }
            else
            {
                return View("Index");
            }
        }

        [HttpPost]
        public IActionResult EditCourse(int Id, Course newCourse)
        {
            if (newCourse.Name != null)
            {
                var oldCourse = context.courses.FirstOrDefault(c => c.Id == Id);
                oldCourse.Name = newCourse.Name;
                oldCourse.Dgree = newCourse.Dgree;
                oldCourse.MinDegree = newCourse.MinDegree;
                oldCourse.Dept_id = newCourse.Dept_id;

                context.SaveChanges();
                return RedirectToAction("Index");
            }

            else
            {
                var depts = context.departments.ToList();
                ViewBag.Depts = depts;
                return View(newCourse);
            }
        }


    }
}

