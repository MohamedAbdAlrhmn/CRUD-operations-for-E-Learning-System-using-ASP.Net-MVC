﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MVCAssignment2.Models
{
    public class Instructor
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int Age { get; set; }

        public string Address { get; set; }
        
        public decimal Salary { get; set; }
        [ForeignKey("Department")]
        public int? Dept_id { get; set; }

        [ForeignKey("Course")]
        public int? Crs_id { get; set; }

        //Navigation property for Department Table
        public virtual Department Department { get; set; }

        //Navigation property for Course Table
        public virtual Course Course { get; set; }
    } 
}
