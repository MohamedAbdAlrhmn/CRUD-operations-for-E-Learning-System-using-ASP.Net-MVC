﻿namespace MVCAssignment2.Models
{
    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ManagerName { get; set; }


        //Navigation property for Instructor Table
        public virtual List<Instructor> Instructors { get; set; }

        //Navigation property for Course Table
        public virtual List<Course> Courses { get; set; }

        //Navigation property for Trainee Table
        public virtual List<Trainee>Trainees { get; set; }
    }
}
