﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MVCAssignment2.Models
{
    public class Trainee
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int Age { get; set; }

        public string Address { get; set; }

        public string Grade { get; set; }

        [ForeignKey("Department")]
        public int? Dept_id { get; set; }

        //Navigation property for Department Table
        public virtual Department Department { get; set; }

        //Navigation property for CrsResult
        public virtual List<CrsResult>CrsResults { get; set; }
    }
}
