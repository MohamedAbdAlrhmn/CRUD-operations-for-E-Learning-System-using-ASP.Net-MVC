﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MVCAssignment2.Models
{
    public class Course
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int Dgree { get; set; }

        public int MinDegree { get; set; }

        [ForeignKey("Department")]
        public int? Dept_id { get; set; }

        //Navigation property for Department Table
        public virtual Department Department { get; set; }

        //Navigation property for Instructor Table
        public virtual List<Instructor> Instructors { get; set; }

        //Navigation property for CrsResult Table
        public virtual List<CrsResult>CrsResults { get; set; }
    }
}
