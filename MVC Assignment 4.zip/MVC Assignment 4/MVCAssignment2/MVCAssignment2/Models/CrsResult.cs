﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MVCAssignment2.Models
{
    public class CrsResult
    {
        public int Id { get; set; }

        public int Degree { get; set; }

        [ForeignKey("Course")]
        public int? crs_id { get; set; }

        [ForeignKey("Trainee")]
        public int? trainee_id { get; set; }  
        //Navigation property for Course Table
        public virtual Course Course { get; set; }

        //Navigation property for Trainee
        public virtual Trainee Trainee { get; set; }
    }
}
